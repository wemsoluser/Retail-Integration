﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Configuration;

namespace SpCommunicator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        string response;
        private const string EOL = "----END----\r\n";
        private const string regex = @"[^0-9.]";
        private static string strCommand = string.Empty;
        private static bool isEcho = false;
        private static string strResponse = string.Empty;
        SerialPort objSerPort = new SerialPort(ConfigurationManager.AppSettings["CommPort"]);
        Thread TxnThread;

        private void cmb_application_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_application.Text.Equals("Debit/Credit"))
            {
                cmb_txn.SelectedIndex = 0;
                grp_debit_credit.Text = "Debit/Credit";
                grp_debit_credit.Visible = true;
            }
            else if (cmb_application.Text.Equals("Keenu Pay"))
            {
                cmb_txn.SelectedIndex = 0;
                grp_debit_credit.Text = "Keenu Pay";
                grp_debit_credit.Visible = true;
            }
            else if (cmb_application.Text.Equals("Loyalty"))
            {
                cmb_txn.SelectedIndex = 0;
                grp_debit_credit.Text = "Loyalty";
                grp_debit_credit.Visible = true;
            }
        }

        private void cmb_txn_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.lbl_amount.Enabled = true;
            this.txt_amount.Enabled = true;
            if (cmb_txn.Text.Equals("Sales"))
            {
                this.lbl_amount.Text = "Enter Amount";
                this.txt_amount.MaxLength = 8;
                this.txt_amount.Text = string.Empty;

            }
            else if (cmb_txn.Text.Equals("Void"))
            {
                this.lbl_amount.Text = "Enter Invoice Number";
                this.txt_amount.MaxLength = 6;
                this.txt_amount.Text = string.Empty;

            }
            else if (cmb_txn.Text.Equals("Echo"))
            {
                this.lbl_amount.Enabled = false;
                this.txt_amount.Enabled = false;
            }
            else if (cmb_txn.Text.Equals("Award"))
            {
                this.txt_amount.MaxLength = 5;
                this.lbl_amount.Enabled = true;
                this.txt_amount.Enabled = true;
            }
            else if (cmb_txn.Text.Equals("Product"))
            {
                this.lbl_amount.Enabled = false;
                this.txt_amount.Enabled = false;
            }
            else if (cmb_txn.Text.Equals("Void Loyalty"))
            {
                this.lbl_amount.Text = "Enter Invoice Number";
                this.txt_amount.MaxLength = 6;
                this.txt_amount.Text = string.Empty;

            }
        }

        private void btn_Send_Click(object sender, EventArgs e)
        {
            response = string.Empty;
            isEcho = false;
            Thread.Sleep(2000);
            if (!ValidateTxnParameters())
                return;
            strCommand = string.Empty;
            this.Transaction.Items.Clear();
            listBox2.Items.Clear();
            string strAmount = txt_amount.Text.ToString();
            if (cmb_txn.Text.Equals("Sales"))
            {
                //string strExtra;
                //strExtra = "2";
                //strAmount = strExtra + strAmount;
                //strAmount = strAmount.PadRight(strAmount.Length + 2, '0');
                // strAmount = strAmount + "66";
                //strAmount = strAmount.PadRight(strAmount.Length + 2, '0');
                strAmount = strAmount.PadLeft(12, '0');
                strCommand = "0200000" + strAmount;

                isEcho = false;
            }
            else if (cmb_txn.Text.Equals("Void"))
            {
                strCommand = "0400000000000" + txt_amount.Text.ToString();
                isEcho = false;

            }
            else if (cmb_txn.Text.Equals("Echo"))
            {
                strCommand = "0800000000000000000";
                isEcho = true;
            }
            else if (cmb_txn.Text.Equals("Award"))
            {
                strAmount = strAmount.PadRight(strAmount.Length + 2, '0');
                strAmount = strAmount.PadLeft(13, '0');
                strCommand = "0300001" + strAmount; ;
                isEcho = false;

            }
            else if (cmb_txn.Text.Equals("Product"))
            {
                strCommand = "03000020000000000000";
                isEcho = false;
            }
            else if (cmb_txn.Text.Equals("Void Loyalty"))
            {
                strAmount = txt_amount.Text.ToString();
                strAmount = strAmount.PadLeft(6, '0');
                strCommand = "0900000000000" + strAmount;
                isEcho = false;
            }
            else if (cmb_txn.Text.Equals("Redemption"))
            {
                strAmount = strAmount.PadRight(strAmount.Length + 2, '0');
                strAmount = strAmount.PadLeft(13, '0');
                strCommand = "012000" + strAmount; ;
                isEcho = false;
            }

            this.TxnThread =
                new Thread(new ThreadStart(this.SendReceiveTxn));

            this.TxnThread.Start();

        }

        private void SendReceiveTxn()
        {

            objSerPort.BaudRate = 115200;
            objSerPort.Parity = Parity.None;
            objSerPort.StopBits = StopBits.One;
            objSerPort.DataBits = 8;
            objSerPort.Handshake = Handshake.None;
            objSerPort.WriteTimeout = 500;
            objSerPort.ReadTimeout = 60000;
            objSerPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);
            try
            {
                if (!objSerPort.IsOpen)
                    objSerPort.Open();
                if (isEcho)
                {
                    while (isEcho == true)
                    {
                        objSerPort.Write(strCommand);
                        Thread.Sleep(5000);
                    }
                }
                else
                    objSerPort.Write(strCommand);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message.ToString());
            }
            //objSerPort.Close();

        }

        private bool ValidateTxnParameters()
        {
            if (cmb_txn.Text.Equals("Sales"))
            {
                if (txt_amount.Text.Length <= 0 || Convert.ToInt32(txt_amount.Text.ToString()) <= 0)
                {
                    MessageBox.Show("Invalid Amount.");
                    return false;
                }
            }
            else if (cmb_txn.Text.Equals("Void"))
            {
                if (txt_amount.Text.Length != 6)
                {
                    MessageBox.Show("Please enter 6 Digits Invoice Number.");
                    return false;
                }
            }
            if (cmb_txn.Text.Equals("Award"))
            {
                //if (txt_amount.Text.Length <= 0 || Convert.ToInt32(txt_amount.Text.ToString()) <= 0)
                //{
                //    MessageBox.Show("Invalid Amount.");
                //    return false;
                //}
            }
            return true;
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;

            strResponse = sp.ReadExisting();
            response += strResponse;// + "\r\n";

            this.UpdateData(strResponse);

            //if (response.Contains(EOL))
            //{
            //    //
            //}
            //Transaction.Items.Add(strResponse);
            return;
        }

        private void UpdateData(string Data)
        {

            if (this.listBox2.InvokeRequired)
            {
                SerialPortCommunicator spc = new SerialPortCommunicator();
                AsyncCallback d = new AsyncCallback(UpdateData);
                this.Invoke(d, new object[] { spc });
            }
            else
            {
                this.listBox2.Items.Add(strResponse);
            }
        }

        private void UpdateData(IAsyncResult ar)
        {
            string[] arr = strResponse.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            //string[] arr = strResponse.Split('\n');
            foreach (string s in arr)
                this.listBox2.Items.Add(s);


            if (response.Contains(EOL))
            {
                this.Transaction.Items.Clear();
                string[] arr1 = response.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                foreach (string s in arr1)
                    this.Transaction.Items.Add(s);
            }
            else if (response == "0800010000000000000")
            {
                this.Transaction.Items.Add(response);
                response = string.Empty;
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void formclose(object sender, EventArgs e)
        {
            isEcho = false;
            Thread.Sleep(2000);
            //this.Close();
        }

        private void txt_amount_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txt_amount.Text, regex))
            {
                //MessageBox.Show("Please enter only numbers.");
                txt_amount.Text = txt_amount.Text.Remove(txt_amount.Text.Length - 1);
                txt_amount.SelectAll();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
