﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Configuration;

namespace SpCommunicator
{
    public class SerialPortCommunicator:IAsyncResult
    {
        //Properties
        private TransactionType enTxnType { get; set; }
        private string strAmount { get; set; }
        private string strInvoice { get; set; }

        public SerialPort objSerPort = new SerialPort(ConfigurationManager.AppSettings["CommPort"]);
        public string DoTransaction(TransactionType enTxnType, string strAmount, string strInvoice)
        {
            this.enTxnType = enTxnType;
            this.strAmount = strAmount;
            this.strInvoice = strInvoice;
            return SendReceiveTxn();
        }

        private string SendReceiveTxn()
        {
            string message;
            objSerPort.BaudRate = 115200;
            objSerPort.Parity = Parity.None;
            objSerPort.StopBits = StopBits.One;
            objSerPort.DataBits = 8;
            objSerPort.Handshake = Handshake.None;
            objSerPort.WriteTimeout = 500;
            objSerPort.ReadTimeout = 60000;
            objSerPort.Open();
            objSerPort.Write("0200000000000222222");
            objSerPort.Close();
            while (true)
            {
                objSerPort.Open();
                message = objSerPort.ReadLine();

                if (message.Length > 0)
                    break;
            }
            if(objSerPort.IsOpen)
                objSerPort.Close();
            return "";
        }

        public object AsyncState
        {
            get { throw new NotImplementedException(); }
        }

        public System.Threading.WaitHandle AsyncWaitHandle
        {
            get { throw new NotImplementedException(); }
        }

        public bool CompletedSynchronously
        {
            get { throw new NotImplementedException(); }
        }

        public bool IsCompleted
        {
            get { throw new NotImplementedException(); }
        }
    }

    public enum TransactionType
    {
        Sales,
        Void
    };
}
